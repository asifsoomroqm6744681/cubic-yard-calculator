/**
 * app.js – UI wiring, tab switching, form handling, history rendering
 * Requires: calculator.js (window.CYC) and i18n.js (window.I18N)
 */

'use strict';

document.addEventListener('DOMContentLoaded', () => {
    // ── Init i18n ─────────────────────────────────────────────────────────────
    I18N.init();

    // ── Element References ────────────────────────────────────────────────────
    const tabRect = document.getElementById('tab-rect');
    const tabCyl = document.getElementById('tab-cyl');
    const formRect = document.getElementById('form-rect');
    const formCyl = document.getElementById('form-cyl');
    const resultsPanel = document.getElementById('results-panel');
    const resultCuYd = document.getElementById('result-cubic-yards');
    const resultCuFt = document.getElementById('result-cubic-feet');
    const resultB60 = document.getElementById('result-bags-60');
    const resultB80 = document.getElementById('result-bags-80');
    const errorMsg = document.getElementById('error-msg');
    const historyTbody = document.getElementById('history-tbody');
    const historyEmpty = document.getElementById('history-empty');
    const btnClearHist = document.getElementById('btn-clear-history');
    const btnClearRect = document.getElementById('btn-clear-rect');
    const btnClearCyl = document.getElementById('btn-clear-cyl');

    let activeTab = 'rect';

    // ── Tab Switching ─────────────────────────────────────────────────────────
    function setTab(tab) {
        activeTab = tab;
        const isRect = tab === 'rect';

        tabRect.classList.toggle('tab-active', isRect);
        tabCyl.classList.toggle('tab-active', !isRect);
        tabRect.setAttribute('aria-selected', isRect);
        tabCyl.setAttribute('aria-selected', !isRect);

        formRect.classList.toggle('hidden', !isRect);
        formCyl.classList.toggle('hidden', isRect);

        hideError();
        hideResults();
    }

    tabRect?.addEventListener('click', () => setTab('rect'));
    tabCyl?.addEventListener('click', () => setTab('cyl'));

    // ── Form Submit – Rectangle ───────────────────────────────────────────────
    formRect?.addEventListener('submit', e => {
        e.preventDefault();
        const length = parseFloat(document.getElementById('rect-length').value);
        const width = parseFloat(document.getElementById('rect-width').value);
        const depth = parseFloat(document.getElementById('rect-depth').value);
        const unit = document.getElementById('rect-unit').value;

        if (!validate(length, width, depth)) return;

        const result = CYC.calculateRectangle(length, width, depth, unit);
        showResults(result);
        CYC.saveHistory({ shape: 'Rectangle', ...result, length, width, depth, unit });
        renderHistory();
    });

    // ── Form Submit – Cylinder ────────────────────────────────────────────────
    formCyl?.addEventListener('submit', e => {
        e.preventDefault();
        const diameter = parseFloat(document.getElementById('cyl-diameter').value);
        const depth = parseFloat(document.getElementById('cyl-depth').value);
        const unit = document.getElementById('cyl-unit').value;

        if (!validate(diameter, depth)) return;

        const result = CYC.calculateCylinder(diameter, depth, unit);
        showResults(result);
        CYC.saveHistory({ shape: 'Cylinder', ...result, diameter, depth, unit });
        renderHistory();
    });

    // ── Clear Buttons ─────────────────────────────────────────────────────────
    btnClearRect?.addEventListener('click', () => {
        formRect.reset();
        hideResults();
        hideError();
    });
    btnClearCyl?.addEventListener('click', () => {
        formCyl.reset();
        hideResults();
        hideError();
    });

    // ── History ───────────────────────────────────────────────────────────────
    btnClearHist?.addEventListener('click', () => {
        CYC.clearHistory();
        renderHistory();
    });

    function renderHistory() {
        const history = CYC.loadHistory();
        if (!historyTbody) return;

        historyTbody.innerHTML = '';

        if (history.length === 0) {
            historyEmpty?.classList.remove('hidden');
            return;
        }
        historyEmpty?.classList.add('hidden');

        history.forEach(entry => {
            const date = new Date(entry.timestamp).toLocaleDateString(undefined, {
                month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
            });
            const tr = document.createElement('tr');
            tr.className = 'border-b border-brand-slatelit hover:bg-brand-slatelit/40 transition-colors';
            tr.innerHTML = `
        <td class="px-4 py-3 text-xs text-slate-400 whitespace-nowrap">${date}</td>
        <td class="px-4 py-3 text-sm font-medium text-white">${entry.shape}</td>
        <td class="px-4 py-3 text-sm text-brand-amber font-semibold">${CYC.fmt(entry.cubicYards)}</td>
        <td class="px-4 py-3 text-sm text-slate-300">${CYC.fmt(entry.cubicFeet)}</td>
      `;
            historyTbody.appendChild(tr);
        });
    }

    // ── Validation ────────────────────────────────────────────────────────────
    function validate(...values) {
        hideError();
        const allNumbers = values.every(v => !isNaN(v) && isFinite(v));
        const allPositive = values.every(v => v > 0);

        if (!allNumbers || !allPositive) {
            showError(I18N.get('err_positive') || 'All values must be greater than zero.');
            return false;
        }
        return true;
    }

    // ── UI Helpers ────────────────────────────────────────────────────────────
    function showResults(result) {
        resultsPanel?.classList.remove('hidden');
        resultsPanel?.classList.add('animate-fade-in');

        if (resultCuYd) resultCuYd.textContent = CYC.fmt(result.cubicYards);
        if (resultCuFt) resultCuFt.textContent = CYC.fmt(result.cubicFeet);
        if (resultB60) resultB60.textContent = result.bags60.toLocaleString();
        if (resultB80) resultB80.textContent = result.bags80.toLocaleString();

        resultsPanel?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function hideResults() {
        resultsPanel?.classList.add('hidden');
        resultsPanel?.classList.remove('animate-fade-in');
    }

    function showError(msg) {
        if (errorMsg) {
            errorMsg.textContent = msg;
            errorMsg.classList.remove('hidden');
        }
    }

    function hideError() {
        errorMsg?.classList.add('hidden');
    }

    // ── Bootstrap ─────────────────────────────────────────────────────────────
    setTab('rect');
    renderHistory();
});
