/**
 * calculator.js – Pure calculation engine + localStorage history
 * No external dependencies.
 */

'use strict';

// ─── Constants ────────────────────────────────────────────────────────────────
const FT_PER_YD = 3;
const CU_YD = 27;           // cubic feet per cubic yard
const BAG_60_FT3 = 0.45;         // cubic feet per 60-lb bag
const BAG_80_FT3 = 0.60;         // cubic feet per 80-lb bag
const PI = Math.PI;
const HISTORY_KEY = 'cyc_history';
const MAX_HISTORY = 50;

// ─── Unit Conversion ──────────────────────────────────────────────────────────
/**
 * Convert a measurement to feet.
 * @param {number} value
 * @param {'ft'|'in'|'cm'} unit
 * @returns {number} value in feet
 */
function toFeet(value, unit) {
    switch (unit) {
        case 'in': return value / 12;
        case 'cm': return value / 30.48;
        default: return value;          // already feet
    }
}

// ─── Core Calculations ────────────────────────────────────────────────────────
/**
 * Rectangular / square slab calculation.
 * @param {number} length  – raw input
 * @param {number} width   – raw input
 * @param {number} depth   – raw input
 * @param {'ft'|'in'|'cm'} unit – applies to ALL three dimensions
 * @returns {{ cubicYards: number, cubicFeet: number, bags60: number, bags80: number }}
 */
function calculateRectangle(length, width, depth, unit) {
    const l = toFeet(length, unit);
    const w = toFeet(width, unit);
    const d = toFeet(depth, unit);

    const cubicFeet = l * w * d;
    const cubicYards = cubicFeet / CU_YD;
    const bags60 = Math.ceil(cubicFeet / BAG_60_FT3);
    const bags80 = Math.ceil(cubicFeet / BAG_80_FT3);

    return { cubicYards, cubicFeet, bags60, bags80 };
}

/**
 * Cylindrical column / round area calculation.
 * @param {number} diameter – raw input
 * @param {number} depth    – raw input
 * @param {'ft'|'in'|'cm'} unit
 * @returns {{ cubicYards: number, cubicFeet: number, bags60: number, bags80: number }}
 */
function calculateCylinder(diameter, depth, unit) {
    const d = toFeet(diameter, unit);
    const dp = toFeet(depth, unit);

    const radius = d / 2;
    const cubicFeet = PI * radius * radius * dp;
    const cubicYards = cubicFeet / CU_YD;
    const bags60 = Math.ceil(cubicFeet / BAG_60_FT3);
    const bags80 = Math.ceil(cubicFeet / BAG_80_FT3);

    return { cubicYards, cubicFeet, bags60, bags80 };
}

// ─── History Management ───────────────────────────────────────────────────────
/**
 * Load all saved calculations from localStorage.
 * @returns {Array<Object>}
 */
function loadHistory() {
    try {
        return JSON.parse(localStorage.getItem(HISTORY_KEY)) || [];
    } catch {
        return [];
    }
}

/**
 * Save a new calculation entry to history.
 * @param {Object} entry
 */
function saveHistory(entry) {
    const history = loadHistory();
    history.unshift({
        ...entry,
        id: Date.now(),
        timestamp: new Date().toISOString(),
    });
    // Cap at MAX_HISTORY entries
    if (history.length > MAX_HISTORY) history.length = MAX_HISTORY;
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
}

/**
 * Remove all history entries.
 */
function clearHistory() {
    localStorage.removeItem(HISTORY_KEY);
}

// ─── Formatting Helpers ───────────────────────────────────────────────────────
/**
 * Round to N decimal places.
 */
function round(value, decimals = 4) {
    return Math.round(value * Math.pow(10, decimals)) / Math.pow(10, decimals);
}

/**
 * Format a number for display (3 decimal places with comma thousands).
 */
function fmt(value) {
    return value.toLocaleString(undefined, { minimumFractionDigits: 3, maximumFractionDigits: 3 });
}

// ─── Public API ───────────────────────────────────────────────────────────────
window.CYC = {
    calculateRectangle,
    calculateCylinder,
    saveHistory,
    loadHistory,
    clearHistory,
    round,
    fmt,
};
