/**
 * i18n.js – Client-side language switcher
 * Updates all [data-i18n] elements without a full page reload.
 */

'use strict';

const I18N = (() => {
    let _strings = {};

    /**
     * Fetch a language JSON file and apply it to the DOM.
     * @param {string} lang – 'en' | 'es' | 'fr'
     */
    async function load(lang) {
        try {
            const base = window.CYC_BASE || '/';
            const resp = await fetch(`${base}lang/${lang}.json`);
            if (!resp.ok) throw new Error('Language file not found');
            _strings = await resp.json();
            applyStrings();
            updateLangButtons(lang);
            document.documentElement.lang = lang;
        } catch (err) {
            console.warn('[i18n] Could not load language:', lang, err);
        }
    }

    /**
     * Apply loaded strings to all elements with [data-i18n] attributes.
     * - data-i18n="key"            → sets textContent
     * - data-i18n-placeholder="key" → sets placeholder attribute
     * - data-i18n-title="key"       → sets title attribute
     */
    function applyStrings() {
        // Text content
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (_strings[key] !== undefined) el.textContent = _strings[key];
        });
        // Placeholders
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            if (_strings[key] !== undefined) el.placeholder = _strings[key];
        });
        // Titles
        document.querySelectorAll('[data-i18n-title]').forEach(el => {
            const key = el.getAttribute('data-i18n-title');
            if (_strings[key] !== undefined) el.title = _strings[key];
        });
    }

    /**
     * Highlight the active language button.
     */
    function updateLangButtons(activeLang) {
        document.querySelectorAll('[data-lang-btn]').forEach(btn => {
            const isActive = btn.dataset.langBtn === activeLang;
            btn.classList.toggle('active-lang', isActive);
        });
    }

    /**
     * Get a translation string by key.
     */
    function get(key) {
        return _strings[key] || key;
    }

    /**
     * Initialize: wire up language buttons and apply existing PHP-rendered lang.
     */
    function init() {
        // JS-side language buttons (if any are added dynamically)
        document.querySelectorAll('[data-lang-btn]').forEach(btn => {
            btn.addEventListener('click', () => {
                const lang = btn.dataset.langBtn;
                load(lang);
                // Persist choice in URL without reload (for SPA-ish feel)
                const url = new URL(window.location.href);
                url.searchParams.set('lang', lang);
                history.replaceState({}, '', url);
            });
        });
    }

    return { init, load, get };
})();

window.I18N = I18N;
