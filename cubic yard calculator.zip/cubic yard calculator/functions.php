<?php
/**
 * functions.php – i18n helpers and shared utilities
 */

// ─── Language Detection ──────────────────────────────────────────────────────
function getCurrentLang(): string {
    $allowed = ['en', 'es', 'fr', 'de', 'ja', 'nl', 'it', 'sv', 'pt', 'ar', 'ru', 'id', 'tr', 'vi'];
    $lang = $_GET['lang'] ?? ($_SESSION['lang'] ?? 'en');
    return in_array($lang, $allowed, true) ? $lang : 'en';
}

function getBaseUrl(): string {
    $path = str_replace('\\', '/', __DIR__);
    $root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
    $relative = str_replace($root, '', $path);
    return rtrim($relative, '/') . '/';
}

// ─── Load Language JSON ──────────────────────────────────────────────────────
function loadLang(string $lang): array {
    $file = __DIR__ . '/lang/' . $lang . '.json';
    if (!file_exists($file)) {
        $file = __DIR__ . '/lang/en.json';
    }
    $json = file_get_contents($file);
    return json_decode($json, true) ?? [];
}

// ─── Translation Helper ──────────────────────────────────────────────────────
function t(string $key, array $strings, string $default = ''): string {
    return htmlspecialchars($strings[$key] ?? $default ?: $key, ENT_QUOTES, 'UTF-8');
}

// ─── Page Meta Helper ────────────────────────────────────────────────────────
function pageMeta(array $strings, string $titleKey = 'meta_title', string $descKey = 'meta_description'): array {
    return [
        'title'       => $strings[$titleKey] ?? 'Cubic Yard Calculator',
        'description' => $strings[$descKey] ?? 'Calculate cubic yards for any project.',
        'url'         => (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
                         . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
                         . ($_SERVER['REQUEST_URI'] ?? '/'),
    ];
}
