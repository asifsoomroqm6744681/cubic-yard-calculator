﻿<?php
/**
 * index.php - Main Controller / Homepage
 * Cubic Yard Calculator
 */
require_once __DIR__ . '/functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$baseUrl = getBaseUrl();
$meta    = pageMeta($strings, 'meta_title', 'meta_description');

$meta['title']       = $strings['meta_title']       ?? 'Cubic Yard Calculator - Free Online Tool for Concrete, Dirt & Gravel';
$meta['description'] = $strings['meta_description'] ?? 'Instantly calculate cubic yards for rectangular and cylindrical areas. Results in cubic yards, cubic feet, and bag counts.';

$siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
           . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');

$jsonld = json_encode([
  '@context'            => 'https://schema.org',
  '@type'               => 'SoftwareApplication',
  'name'                => 'Cubic Yard Calculator',
  'applicationCategory' => 'UtilitiesApplication',
  'operatingSystem'     => 'Web',
  'offers'              => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'USD'],
  'url'                 => $siteUrl,
  'description'         => $meta['description'],
  'featureList'         => [
    'Rectangular volume calculation',
    'Cylindrical volume calculation',
    'Unit conversion (feet, inches, centimeters)',
    'Bag count estimation (60lb and 80lb)',
    'Calculation history saved to browser',
    'Multi-language support (English, Spanish, French)',
  ],
], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

include __DIR__ . '/inc/header.php';
?>

<!-- Hero -->
<section class="hero-gradient py-12 px-4 md:py-16 text-center">
  <div class="max-w-3xl mx-auto">
    <div class="inline-flex items-center gap-2 bg-brand-slatelit/60 border border-brand-slatelit rounded-full px-4 py-1.5 text-xs text-brand-amber font-semibold uppercase tracking-widest mb-5">
      <span>&#9889;</span> Free Professional Tool
    </div>
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4" data-i18n="hero_title">
      <?php echo t('hero_title', $strings); ?>
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed" data-i18n="hero_subtitle">
      <?php echo t('hero_subtitle', $strings); ?>
    </p>
  </div>
</section>

<!-- Calculator -->
<section class="max-w-6xl mx-auto px-4 py-8 md:py-10" aria-label="Calculator">
  <div class="grid grid-cols-1 lg:grid-cols-5 gap-6">

    <!-- Input Panel -->
    <div class="lg:col-span-3 panel p-6 md:p-8">

      <!-- Tabs -->
      <div class="flex bg-brand-slate rounded-xl p-1 mb-6 gap-1" role="tablist">
        <button id="tab-rect" class="tab-btn flex-1 tab-active"
                role="tab" aria-selected="true" aria-controls="form-rect" data-i18n="tab_rectangle">
          <?php echo t('tab_rectangle', $strings); ?>
        </button>
        <button id="tab-cyl" class="tab-btn flex-1"
                role="tab" aria-selected="false" aria-controls="form-cyl" data-i18n="tab_cylinder">
          <?php echo t('tab_cylinder', $strings); ?>
        </button>
      </div>

      <!-- Error -->
      <div id="error-msg" class="hidden mb-4 rounded-lg bg-red-900/40 border border-red-700 text-red-300 px-4 py-3 text-sm" role="alert"></div>

      <!-- Rectangle Form -->
      <form id="form-rect" novalidate>
        <fieldset class="border-0 p-0 m-0 space-y-4">
          <legend class="sr-only">Rectangular area inputs</legend>
          <div class="flex items-center justify-between mb-2">
            <span class="text-sm font-semibold text-slate-400 uppercase tracking-wider">Unit of Measurement</span>
            <select id="rect-unit" class="calc-input w-36 text-sm">
              <option value="ft"><?php echo t('label_unit_ft', $strings); ?></option>
              <option value="in"><?php echo t('label_unit_in', $strings); ?></option>
              <option value="cm"><?php echo t('label_unit_cm', $strings); ?></option>
            </select>
          </div>
          <div>
            <label for="rect-length" class="block text-sm font-semibold text-slate-300 mb-1.5" data-i18n="label_length">
              <?php echo t('label_length', $strings); ?>
            </label>
            <input id="rect-length" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 12" required />
          </div>
          <div>
            <label for="rect-width" class="block text-sm font-semibold text-slate-300 mb-1.5" data-i18n="label_width">
              <?php echo t('label_width', $strings); ?>
            </label>
            <input id="rect-width" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 8" required />
          </div>
          <div>
            <label for="rect-depth" class="block text-sm font-semibold text-slate-300 mb-1.5" data-i18n="label_depth">
              <?php echo t('label_depth', $strings); ?>
            </label>
            <input id="rect-depth" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 4" required />
          </div>
        </fieldset>
        <div class="flex gap-3 mt-6">
          <button type="submit" class="btn-primary flex-1" data-i18n="btn_calculate"><?php echo t('btn_calculate', $strings); ?></button>
          <button type="button" id="btn-clear-rect" class="btn-secondary" data-i18n="btn_clear"><?php echo t('btn_clear', $strings); ?></button>
        </div>
      </form>

      <!-- Cylinder Form -->
      <form id="form-cyl" class="hidden" novalidate>
        <fieldset class="border-0 p-0 m-0 space-y-4">
          <legend class="sr-only">Cylindrical area inputs</legend>
          <div class="flex items-center justify-between mb-2">
            <span class="text-sm font-semibold text-slate-400 uppercase tracking-wider">Unit of Measurement</span>
            <select id="cyl-unit" class="calc-input w-36 text-sm">
              <option value="ft"><?php echo t('label_unit_ft', $strings); ?></option>
              <option value="in"><?php echo t('label_unit_in', $strings); ?></option>
              <option value="cm"><?php echo t('label_unit_cm', $strings); ?></option>
            </select>
          </div>
          <div>
            <label for="cyl-diameter" class="block text-sm font-semibold text-slate-300 mb-1.5" data-i18n="label_diameter">
              <?php echo t('label_diameter', $strings); ?>
            </label>
            <input id="cyl-diameter" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 3" required />
          </div>
          <div>
            <label for="cyl-depth" class="block text-sm font-semibold text-slate-300 mb-1.5" data-i18n="label_depth">
              <?php echo t('label_depth', $strings); ?>
            </label>
            <input id="cyl-depth" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 1" required />
          </div>
        </fieldset>
        <div class="flex gap-3 mt-6">
          <button type="submit" class="btn-primary flex-1" data-i18n="btn_calculate"><?php echo t('btn_calculate', $strings); ?></button>
          <button type="button" id="btn-clear-cyl" class="btn-secondary" data-i18n="btn_clear"><?php echo t('btn_clear', $strings); ?></button>
        </div>
      </form>

    </div><!-- /input panel -->

    <!-- Results Panel -->
    <div class="lg:col-span-2 space-y-4">

      <div id="results-panel" class="hidden panel p-6">
        <h2 class="text-lg font-bold text-white mb-4 flex items-center gap-2" data-i18n="result_title">
          <span class="text-brand-amber">&#10003;</span> <?php echo t('result_title', $strings); ?>
        </h2>
        <div class="grid grid-cols-2 gap-3">
          <div class="result-card pulse-amber">
            <div id="result-cubic-yards" class="result-value">&#8212;</div>
            <div class="result-label" data-i18n="result_cubic_yards"><?php echo t('result_cubic_yards', $strings); ?></div>
          </div>
          <div class="result-card">
            <div id="result-cubic-feet" class="result-value" style="color:#7dd3fc">&#8212;</div>
            <div class="result-label" data-i18n="result_cubic_feet"><?php echo t('result_cubic_feet', $strings); ?></div>
          </div>
          <div class="result-card">
            <div id="result-bags-60" class="result-value" style="color:#86efac">&#8212;</div>
            <div class="result-label" data-i18n="result_bags_60"><?php echo t('result_bags_60', $strings); ?></div>
          </div>
          <div class="result-card">
            <div id="result-bags-80" class="result-value" style="color:#fca5a5">&#8212;</div>
            <div class="result-label" data-i18n="result_bags_80"><?php echo t('result_bags_80', $strings); ?></div>
          </div>
        </div>
        <p class="text-xs text-slate-500 mt-3 leading-relaxed" data-i18n="result_note"><?php echo t('result_note', $strings); ?></p>
      </div>

      <!-- Quick Reference -->
      <div class="panel p-5">
        <h3 class="text-sm font-bold text-white mb-3 uppercase tracking-wider">&#128207; Quick Reference</h3>
        <ul class="space-y-1.5 text-xs text-slate-400">
          <li class="flex justify-between"><span>1 Cubic Yard</span><span class="text-white font-medium">= 27 Cubic Feet</span></li>
          <li class="flex justify-between"><span>60 lb Bag</span><span class="text-white font-medium">approx 0.45 ft3</span></li>
          <li class="flex justify-between"><span>80 lb Bag</span><span class="text-white font-medium">approx 0.60 ft3</span></li>
          <li class="flex justify-between"><span>1 Foot</span><span class="text-white font-medium">= 12 Inches</span></li>
          <li class="flex justify-between"><span>1 Foot</span><span class="text-white font-medium">approx 30.48 cm</span></li>
        </ul>
        <div class="mt-4 pt-3 border-t border-brand-slatelit text-xs text-slate-500">
          <strong class="text-slate-400">Formula:</strong><br>
          Rectangle: L x W x D div 27<br>
          Cylinder: pi x r2 x D div 27
        </div>
      </div>

    </div><!-- /results col -->
  </div><!-- /grid -->
</section>

<!-- History -->
<section id="history-section" class="max-w-6xl mx-auto px-4 pb-10" aria-label="Calculation History">
  <div class="panel overflow-hidden">
    <div class="flex items-center justify-between px-6 py-4 border-b border-brand-slatelit">
      <h2 class="text-base font-bold text-white" data-i18n="history_title"><?php echo t('history_title', $strings); ?></h2>
      <button id="btn-clear-history" class="text-xs text-slate-500 hover:text-red-400 transition-colors font-medium" data-i18n="btn_clear_history">
        <?php echo t('btn_clear_history', $strings); ?>
      </button>
    </div>
    <div id="history-empty" class="px-6 py-8 text-center text-sm text-slate-500" data-i18n="history_empty">
      <?php echo t('history_empty', $strings); ?>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full history-table" aria-label="History table">
        <thead>
          <tr>
            <th class="text-left" data-i18n="history_col_date"><?php echo t('history_col_date', $strings); ?></th>
            <th class="text-left" data-i18n="history_col_shape"><?php echo t('history_col_shape', $strings); ?></th>
            <th class="text-left" data-i18n="history_col_cubic_yards"><?php echo t('history_col_cubic_yards', $strings); ?></th>
            <th class="text-left" data-i18n="history_col_cubic_feet"><?php echo t('history_col_cubic_feet', $strings); ?></th>
          </tr>
        </thead>
        <tbody id="history-tbody"></tbody>
      </table>
    </div>
  </div>
</section>

<!-- Material Guides -->
<section class="max-w-6xl mx-auto px-4 pb-12">
  <h2 class="text-xl font-bold text-white mb-6 text-center">Explore Material Guides</h2>
  <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
    <a href="<?php echo $baseUrl; ?>concrete?lang=<?php echo $lang; ?>" class="panel p-5 flex items-center gap-4 hover:border-brand-amber border border-transparent transition-all group">
      <span class="text-3xl">&#127959;</span>
      <div>
        <div class="font-semibold text-white group-hover:text-brand-amber transition-colors"><?php echo t('material_concrete', $strings); ?></div>
        <div class="text-xs text-slate-500 mt-0.5">Mix ratios, bag coverage and tips</div>
      </div>
    </a>
    <a href="<?php echo $baseUrl; ?>dirt?lang=<?php echo $lang; ?>" class="panel p-5 flex items-center gap-4 hover:border-brand-amber border border-transparent transition-all group">
      <span class="text-3xl">&#127807;</span>
      <div>
        <div class="font-semibold text-white group-hover:text-brand-amber transition-colors"><?php echo t('material_dirt', $strings); ?></div>
        <div class="text-xs text-slate-500 mt-0.5">Coverage tables and topsoil tips</div>
      </div>
    </a>
    <a href="<?php echo $baseUrl; ?>gravel?lang=<?php echo $lang; ?>" class="panel p-5 flex items-center gap-4 hover:border-brand-amber border border-transparent transition-all group">
      <span class="text-3xl">&#129704;</span>
      <div>
        <div class="font-semibold text-white group-hover:text-brand-amber transition-colors"><?php echo t('material_gravel', $strings); ?></div>
        <div class="text-xs text-slate-500 mt-0.5">Compaction, coverage and types</div>
      </div>
    </a>
  </div>
</section>

<?php include __DIR__ . '/inc/nav.php'; ?>
<?php include __DIR__ . '/inc/footer.php'; ?>
