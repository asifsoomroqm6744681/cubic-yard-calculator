<?php
/**
 * inc/footer.php – Site-wide footer
 * Cubic Yard Calculator
 */
$baseUrl    = getBaseUrl();
$footerLang = $lang ?? 'en';
$currentYear = date('Y');
?>

<!-- ═══════════════════════════════════════════════ FOOTER ══ -->
<footer class="border-t border-brand-slatelit mt-auto">
  <div class="max-w-6xl mx-auto px-4 py-10">
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mb-8">

      <!-- Brand -->
      <div>
        <a href="<?php echo $baseUrl; ?>" class="flex items-center gap-2 mb-3">
          <span class="text-brand-amber text-xl font-black">⬛</span>
          <span class="font-extrabold text-white text-base tracking-tight">
            Cubic<span class="text-brand-amber">Yard</span>
          </span>
        </a>
        <p class="text-xs text-slate-500 leading-relaxed">
          Free professional tool for calculating cubic yards of concrete, dirt, gravel and more.
        </p>
      </div>

      <!-- Calculators -->
      <div>
        <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Calculators</h3>
        <ul class="space-y-2 text-sm text-slate-500">
          <li><a href="<?php echo $baseUrl; ?>?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors">Cubic Yard Calculator</a></li>
          <li><a href="<?php echo $baseUrl; ?>concrete?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors">Concrete Calculator</a></li>
          <li><a href="<?php echo $baseUrl; ?>dirt?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors">Dirt & Topsoil</a></li>
          <li><a href="<?php echo $baseUrl; ?>gravel?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors">Gravel Calculator</a></li>
        </ul>
      </div>

      <!-- Guides -->
      <div>
        <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Guides</h3>
        <ul class="space-y-2 text-sm text-slate-500">
          <li><a href="<?php echo $baseUrl; ?>what-is-cubic-yard-calculator?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors">What Is a Cubic Yard?</a></li>
          <li><a href="<?php echo $baseUrl; ?>how-to-use?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors">How To Use</a></li>
          <li><a href="<?php echo $baseUrl; ?>about-us?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors"><?php echo t('page_about_title', $strings); ?></a></li>
          <li><a href="<?php echo $baseUrl; ?>contact?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors"><?php echo t('page_contact_title', $strings); ?></a></li>
        </ul>
      </div>

      <!-- Legal -->
      <div>
        <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3"><?php echo t('footer_legal_title', $strings); ?></h3>
        <ul class="space-y-2 text-sm text-slate-500">
          <li><a href="<?php echo $baseUrl; ?>privacy-policy?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors"><?php echo t('page_privacy_title', $strings); ?></a></li>
          <li><a href="<?php echo $baseUrl; ?>terms-and-conditions?lang=<?php echo $footerLang; ?>" class="hover:text-brand-amber transition-colors"><?php echo t('page_terms_title', $strings); ?></a></li>
        </ul>
      </div>

    </div>

    <!-- Bottom Bar -->
    <div class="border-t border-brand-slatelit pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
      <p>&copy; <?php echo $currentYear; ?> CubicYard Calculator. All rights reserved.</p>
      <div class="flex flex-wrap gap-x-4 gap-y-2 justify-center sm:justify-end max-w-lg">
        <span>🇺🇸 <a href="?lang=en" class="hover:text-slate-400 transition-colors">English</a></span>
        <span>🇪🇸 <a href="?lang=es" class="hover:text-slate-400 transition-colors">Español</a></span>
        <span>🇫🇷 <a href="?lang=fr" class="hover:text-slate-400 transition-colors">Français</a></span>
        <span>🇩🇪 <a href="?lang=de" class="hover:text-slate-400 transition-colors">Deutsch</a></span>
        <span>🇯🇵 <a href="?lang=ja" class="hover:text-slate-400 transition-colors">日本語</a></span>
        <span>🇳🇱 <a href="?lang=nl" class="hover:text-slate-400 transition-colors">Nederlands</a></span>
        <span>🇮🇹 <a href="?lang=it" class="hover:text-slate-400 transition-colors">Italiano</a></span>
        <span>🇸🇪 <a href="?lang=sv" class="hover:text-slate-400 transition-colors">Svenska</a></span>
        <span>🇵🇹 <a href="?lang=pt" class="hover:text-slate-400 transition-colors">Português</a></span>
        <span>🇸🇦 <a href="?lang=ar" class="hover:text-slate-400 transition-colors">العربية</a></span>
        <span>🇷🇺 <a href="?lang=ru" class="hover:text-slate-400 transition-colors">Русский</a></span>
        <span>🇮🇩 <a href="?lang=id" class="hover:text-slate-400 transition-colors">Bahasa Indonesia</a></span>
        <span>🇹🇷 <a href="?lang=tr" class="hover:text-slate-400 transition-colors">Türkçe</a></span>
        <span>🇻🇳 <a href="?lang=vi" class="hover:text-slate-400 transition-colors">Tiếng Việt</a></span>
      </div>
    </div>
  </div>
</footer>


</body>
</html>
