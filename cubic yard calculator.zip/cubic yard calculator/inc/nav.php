<?php
/**
 * inc/nav.php – Breadcrumb / bottom navigation (optional)
 * Included after main content sections in pages.
 */
$baseUrl = getBaseUrl();
$navLang = $lang ?? 'en';
?>

<!-- ══════════════════════════════ BOTTOM NAV / BREADCRUMB ══ -->
<nav class="max-w-6xl mx-auto px-4 pb-8" aria-label="Breadcrumb">
  <ol class="flex flex-wrap items-center gap-2 text-xs text-slate-500">
    <li>
      <a href="<?php echo $baseUrl; ?>?lang=<?php echo $navLang; ?>" class="hover:text-brand-amber transition-colors inline-flex items-center gap-1">
        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
        </svg>
        Home
      </a>
    </li>
    <?php if (!empty($breadcrumb)): ?>
      <li class="text-slate-700" aria-hidden="true">›</li>
      <li class="text-slate-400"><?php echo htmlspecialchars($breadcrumb); ?></li>
    <?php endif; ?>
  </ol>
</nav>
