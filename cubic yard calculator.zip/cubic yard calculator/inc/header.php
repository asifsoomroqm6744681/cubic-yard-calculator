<?php
/**
 * inc/header.php – Site-wide <head> + navbar
 * Cubic Yard Calculator
 */

$baseUrl = getBaseUrl();
$siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
           . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');

$canonicalUrl = $siteUrl . ($_SERVER['REQUEST_URI'] ?? '/');
$currentLang  = $lang ?? 'en';
$dir = ($currentLang === 'ar') ? 'rtl' : 'ltr';
$pageTitle    = $meta['title']       ?? 'Cubic Yard Calculator – Free Online Tool';
$pageDesc     = $meta['description'] ?? 'Instantly calculate cubic yards for concrete, dirt, gravel & more.';
?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($currentLang); ?>" dir="<?php echo $dir; ?>">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo htmlspecialchars($pageTitle); ?></title>
  <meta name="description" content="<?php echo htmlspecialchars($pageDesc); ?>" />
  <link rel="canonical" href="<?php echo htmlspecialchars($canonicalUrl); ?>" />
  <link rel="icon" type="image/svg+xml" href="<?php echo $baseUrl; ?>favicon.svg" />

  <!-- Open Graph -->
  <meta property="og:type"        content="website" />
  <meta property="og:title"       content="<?php echo htmlspecialchars($pageTitle); ?>" />
  <meta property="og:description" content="<?php echo htmlspecialchars($pageDesc); ?>" />
  <meta property="og:url"         content="<?php echo htmlspecialchars($canonicalUrl); ?>" />

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: {
              amber:    '#F59E0B',
              amberdk:  '#D97706',
              slate:    '#0F172A',
              slatemid: '#1E293B',
              slatelit: '#334155',
              offwhite: '#F8FAFC',
            }
          },
          fontFamily: {
            sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
          }
        }
      }
    }
  </script>

  <!-- Custom CSS -->
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>css/style.css" />

  <!-- JSON-LD Structured Data -->
  <?php if (!empty($jsonld)): ?>
  <script type="application/ld+json">
  <?php echo $jsonld; ?>
  </script>
  <?php endif; ?>

  <!-- JS: load in correct order (calculator → i18n → app) -->
  <script>window.CYC_BASE = "<?php echo $baseUrl; ?>";</script>
  <script src="<?php echo $baseUrl; ?>js/calculator.js"></script>
  <script src="<?php echo $baseUrl; ?>js/i18n.js"></script>
  <script src="<?php echo $baseUrl; ?>js/app.js"></script>

  <style>
    body { font-family: 'Inter', sans-serif; }
    /* Smooth scroll */
    html { scroll-behavior: smooth; }
    /* Navbar glass effect */
    .navbar-glass {
      background: rgba(15, 23, 42, 0.85);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      border-bottom: 1px solid rgba(51, 65, 85, 0.6);
    }
    /* Mobile menu transition */
    #mobile-menu {
      transition: max-height 0.3s ease, opacity 0.3s ease;
      max-height: 0;
      opacity: 0;
      overflow: hidden;
    }
    #mobile-menu.open {
      max-height: 400px;
      opacity: 1;
    }
    /* Active nav link */
    .nav-link-active {
      color: #F59E0B !important;
    }
  </style>
</head>
<body class="bg-brand-slate text-brand-offwhite min-h-screen">

<!-- ═══════════════════════════════════════════════ NAVBAR ══ -->
<header class="navbar-glass sticky top-0 z-50">
  <nav class="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between" aria-label="Main navigation">

    <!-- Logo -->
    <a href="<?php echo $baseUrl; ?>" class="flex items-center gap-2 shrink-0" aria-label="Cubic Yard Calculator Home">
      <span class="text-brand-amber text-2xl font-black leading-none">⬛</span>
      <span class="font-extrabold text-white text-base sm:text-lg tracking-tight leading-tight">
        Cubic<span class="text-brand-amber">Yard</span>
      </span>
    </a>

    <!-- Desktop Nav Links -->
    <ul class="hidden md:flex items-center gap-1 text-sm font-medium text-slate-400">
      <li>
        <a href="<?php echo $baseUrl; ?>?lang=<?php echo $currentLang; ?>"
           class="px-3 py-2 rounded-lg hover:text-white hover:bg-brand-slatemid transition-colors <?php echo (($_SERVER['REQUEST_URI'] ?? '/') === $baseUrl || strpos($_SERVER['REQUEST_URI'] ?? '', ($baseUrl . '?')) === 0) ? 'nav-link-active' : ''; ?>">
          Calculator
        </a>
      </li>
      <li>
        <a href="<?php echo $baseUrl; ?>concrete?lang=<?php echo $currentLang; ?>"
           class="px-3 py-2 rounded-lg hover:text-white hover:bg-brand-slatemid transition-colors <?php echo strpos($_SERVER['REQUEST_URI'] ?? '', $baseUrl . 'concrete') === 0 ? 'nav-link-active' : ''; ?>">
          Concrete
        </a>
      </li>
      <li>
        <a href="<?php echo $baseUrl; ?>dirt?lang=<?php echo $currentLang; ?>"
           class="px-3 py-2 rounded-lg hover:text-white hover:bg-brand-slatemid transition-colors <?php echo strpos($_SERVER['REQUEST_URI'] ?? '', $baseUrl . 'dirt') === 0 ? 'nav-link-active' : ''; ?>">
          Dirt
        </a>
      </li>
      <li>
        <a href="<?php echo $baseUrl; ?>gravel?lang=<?php echo $currentLang; ?>"
           class="px-3 py-2 rounded-lg hover:text-white hover:bg-brand-slatemid transition-colors <?php echo strpos($_SERVER['REQUEST_URI'] ?? '', $baseUrl . 'gravel') === 0 ? 'nav-link-active' : ''; ?>">
          Gravel
        </a>
      </li>
    </ul>

    <!-- Right: Language Switcher + Mobile Hamburger -->
    <div class="flex items-center gap-3">

      <!-- Language Selector -->
      <form method="get" class="hidden sm:flex items-center">
        <?php
          // Preserve existing GET params except lang
          $params = $_GET;
          foreach ($params as $k => $v) {
            if ($k !== 'lang') {
              echo '<input type="hidden" name="' . htmlspecialchars($k) . '" value="' . htmlspecialchars($v) . '" />';
            }
          }
        ?>
        <select name="lang" onchange="this.form.submit()"
                class="bg-brand-slatemid border border-brand-slatelit text-slate-300 text-xs rounded-lg px-2 py-1.5 cursor-pointer focus:outline-none focus:border-brand-amber appearance-none pr-6"
                aria-label="Select language"
                style="background-image:url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 fill=%22none%22 viewBox=%220 0 24 24%22 stroke=%2294a3b8%22 stroke-width=%222%22%3E%3Cpath stroke-linecap=%22round%22 stroke-linejoin=%22round%22 d=%22M19 9l-7 7-7-7%22/%3E%3C/svg%3E'); background-repeat:no-repeat; background-position:right 0.35rem center; background-size:0.75rem;">
          <option value="en" <?php echo $currentLang === 'en' ? 'selected' : ''; ?>>🌐 EN</option>
          <option value="es" <?php echo $currentLang === 'es' ? 'selected' : ''; ?>>🇪🇸 ES</option>
          <option value="fr" <?php echo $currentLang === 'fr' ? 'selected' : ''; ?>>🇫🇷 FR</option>
          <option value="de" <?php echo $currentLang === 'de' ? 'selected' : ''; ?>>🇩🇪 DE</option>
          <option value="ja" <?php echo $currentLang === 'ja' ? 'selected' : ''; ?>>🇯🇵 JA</option>
          <option value="nl" <?php echo $currentLang === 'nl' ? 'selected' : ''; ?>>🇳🇱 NL</option>
          <option value="it" <?php echo $currentLang === 'it' ? 'selected' : ''; ?>>🇮🇹 IT</option>
          <option value="sv" <?php echo $currentLang === 'sv' ? 'selected' : ''; ?>>🇸🇪 SV</option>
          <option value="pt" <?php echo $currentLang === 'pt' ? 'selected' : ''; ?>>🇵🇹 PT</option>
          <option value="ar" <?php echo $currentLang === 'ar' ? 'selected' : ''; ?>>🇸🇦 AR</option>
          <option value="ru" <?php echo $currentLang === 'ru' ? 'selected' : ''; ?>>🇷🇺 RU</option>
          <option value="id" <?php echo $currentLang === 'id' ? 'selected' : ''; ?>>🇮🇩 ID</option>
          <option value="tr" <?php echo $currentLang === 'tr' ? 'selected' : ''; ?>>🇹🇷 TR</option>
          <option value="vi" <?php echo $currentLang === 'vi' ? 'selected' : ''; ?>>🇻🇳 VI</option>
        </select>
      </form>

      <!-- Mobile hamburger -->
      <button id="hamburger-btn" class="md:hidden flex flex-col gap-1.5 p-2 rounded-lg hover:bg-brand-slatemid transition-colors" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu">
        <span class="block w-5 h-0.5 bg-slate-300 transition-all duration-200" id="ham-1"></span>
        <span class="block w-5 h-0.5 bg-slate-300 transition-all duration-200" id="ham-2"></span>
        <span class="block w-5 h-0.5 bg-slate-300 transition-all duration-200" id="ham-3"></span>
      </button>
    </div>
  </nav>

  <!-- Mobile Menu -->
  <div id="mobile-menu" class="md:hidden px-4 pb-0">
    <ul class="flex flex-col gap-1 pb-4 border-t border-brand-slatelit pt-3 text-sm font-medium text-slate-400">
      <li><a href="<?php echo $baseUrl; ?>?lang=<?php echo $currentLang; ?>"          class="block px-3 py-2 rounded-lg hover:text-white hover:bg-brand-slatemid transition-colors">Calculator</a></li>
      <li><a href="<?php echo $baseUrl; ?>concrete?lang=<?php echo $currentLang; ?>"  class="block px-3 py-2 rounded-lg hover:text-white hover:bg-brand-slatemid transition-colors">Concrete</a></li>
      <li><a href="<?php echo $baseUrl; ?>dirt?lang=<?php echo $currentLang; ?>"      class="block px-3 py-2 rounded-lg hover:text-white hover:bg-brand-slatemid transition-colors">Dirt</a></li>
      <li><a href="<?php echo $baseUrl; ?>gravel?lang=<?php echo $currentLang; ?>"    class="block px-3 py-2 rounded-lg hover:text-white hover:bg-brand-slatemid transition-colors">Gravel</a></li>
      <!-- Mobile lang -->
      <li class="pt-2">
        <form method="get" class="flex items-center gap-2">
          <?php
            foreach ($_GET as $k => $v) {
              if ($k !== 'lang') echo '<input type="hidden" name="' . htmlspecialchars($k) . '" value="' . htmlspecialchars($v) . '" />';
            }
          ?>
          <label class="text-xs text-slate-500">Language:</label>
          <select name="lang" onchange="this.form.submit()" class="bg-brand-slatemid border border-brand-slatelit text-slate-300 text-xs rounded-lg px-2 py-1.5 cursor-pointer focus:outline-none">
            <option value="en" <?php echo $currentLang === 'en' ? 'selected' : ''; ?>>English</option>
            <option value="es" <?php echo $currentLang === 'es' ? 'selected' : ''; ?>>Español</option>
            <option value="fr" <?php echo $currentLang === 'fr' ? 'selected' : ''; ?>>Français</option>
            <option value="de" <?php echo $currentLang === 'de' ? 'selected' : ''; ?>>Deutsch</option>
            <option value="ja" <?php echo $currentLang === 'ja' ? 'selected' : ''; ?>>日本語</option>
            <option value="nl" <?php echo $currentLang === 'nl' ? 'selected' : ''; ?>>Nederlands</option>
            <option value="it" <?php echo $currentLang === 'it' ? 'selected' : ''; ?>>Italiano</option>
            <option value="sv" <?php echo $currentLang === 'sv' ? 'selected' : ''; ?>>Svenska</option>
            <option value="pt" <?php echo $currentLang === 'pt' ? 'selected' : ''; ?>>Português</option>
            <option value="ar" <?php echo $currentLang === 'ar' ? 'selected' : ''; ?>>العربية</option>
            <option value="ru" <?php echo $currentLang === 'ru' ? 'selected' : ''; ?>>Русский</option>
            <option value="id" <?php echo $currentLang === 'id' ? 'selected' : ''; ?>>Bahasa Indonesia</option>
            <option value="tr" <?php echo $currentLang === 'tr' ? 'selected' : ''; ?>>Türkçe</option>
            <option value="vi" <?php echo $currentLang === 'vi' ? 'selected' : ''; ?>>Tiếng Việt</option>
          </select>
        </form>
      </li>
    </ul>
  </div>
</header>

<!-- Hamburger JS -->
<script>
(function(){
  const btn  = document.getElementById('hamburger-btn');
  const menu = document.getElementById('mobile-menu');
  const h1   = document.getElementById('ham-1');
  const h2   = document.getElementById('ham-2');
  const h3   = document.getElementById('ham-3');
  if (!btn) return;
  btn.addEventListener('click', function(){
    const open = menu.classList.toggle('open');
    btn.setAttribute('aria-expanded', open);
    if (open) {
      h1.style.transform = 'translateY(8px) rotate(45deg)';
      h2.style.opacity   = '0';
      h3.style.transform = 'translateY(-8px) rotate(-45deg)';
    } else {
      h1.style.transform = '';
      h2.style.opacity   = '';
      h3.style.transform = '';
    }
  });
})();
</script>
