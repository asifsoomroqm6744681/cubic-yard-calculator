<?php
/**
 * pages/dirt.php – Dirt & Topsoil Guide
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = 'Dirt & Topsoil Calculator';

$meta = [
  'title'       => 'Dirt & Topsoil Calculator – Cubic Yards for Fill Dirt | CubicYard',
  'description' => 'Calculate cubic yards of dirt, topsoil or fill needed for any landscaping or construction project. Free online dirt calculator.',
];
$siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
         . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
$jsonld = '';

include __DIR__ . '/../inc/header.php';
?>

<!-- Hero -->
<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <div class="inline-flex items-center gap-2 bg-brand-slatelit/60 border border-brand-slatelit rounded-full px-4 py-1.5 text-xs text-brand-amber font-semibold uppercase tracking-widest mb-5">
      <span>🌱</span> Material Guide
    </div>
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      Dirt &amp; Topsoil Calculator
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      Calculate exactly how much dirt or topsoil you need for your yard or project.
    </p>
  </div>
</section>

<!-- Content -->
<section class="max-w-4xl mx-auto px-4 py-10 prose-dark">

  <!-- Quick-calc embed -->
  <div class="panel p-6 mb-10">
    <h2 class="text-lg font-bold text-white mb-1 flex items-center gap-2">
      <span class="text-brand-amber">⚡</span> Quick Dirt Calculator
    </h2>
    <p class="text-sm text-slate-400 mb-5">Enter your area dimensions:</p>
    <form id="form-rect" novalidate>
      <fieldset class="border-0 p-0 m-0 space-y-4">
        <legend class="sr-only">Rectangular area inputs</legend>
        <div class="flex items-center justify-between mb-2">
          <span class="text-sm font-semibold text-slate-400 uppercase tracking-wider">Unit of Measurement</span>
          <select id="rect-unit" class="calc-input w-36 text-sm">
            <option value="ft">Feet</option>
            <option value="in">Inches</option>
            <option value="cm">Centimeters</option>
          </select>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label for="rect-length" class="block text-sm font-semibold text-slate-300 mb-1.5">Length</label>
            <input id="rect-length" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 20" required />
          </div>
          <div>
            <label for="rect-width" class="block text-sm font-semibold text-slate-300 mb-1.5">Width</label>
            <input id="rect-width" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 15" required />
          </div>
          <div>
            <label for="rect-depth" class="block text-sm font-semibold text-slate-300 mb-1.5">Depth (fill depth)</label>
            <input id="rect-depth" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 0.5" required />
          </div>
        </div>
      </fieldset>
      <div id="error-msg" class="hidden mt-3 rounded-lg bg-red-900/40 border border-red-700 text-red-300 px-4 py-3 text-sm" role="alert"></div>
      <div class="flex gap-3 mt-5">
        <button type="submit" class="btn-primary flex-1">Calculate Dirt Needed</button>
        <button type="button" id="btn-clear-rect" class="btn-secondary">Clear</button>
      </div>
    </form>
    <div id="results-panel" class="hidden mt-6 pt-5 border-t border-brand-slatelit">
      <h3 class="text-base font-bold text-white mb-3 flex items-center gap-2">
        <span class="text-brand-amber">✓</span> Your Results
      </h3>
      <div class="grid grid-cols-2 gap-3">
        <div class="result-card pulse-amber">
          <div id="result-cubic-yards" class="result-value">—</div>
          <div class="result-label">Cubic Yards</div>
        </div>
        <div class="result-card">
          <div id="result-cubic-feet" class="result-value" style="color:#7dd3fc">—</div>
          <div class="result-label">Cubic Feet</div>
        </div>
        <div id="result-bags-60" class="hidden"></div>
        <div id="result-bags-80" class="hidden"></div>
      </div>
    </div>
  </div>

  <h2>Types of Dirt &amp; Topsoil</h2>

  <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 not-prose my-6">
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">🌱 Topsoil</div>
      <div class="text-slate-400 text-sm">Rich organic matter. Perfect for lawns, gardens, and planting beds. Typically the top 2–8 inches of earth.</div>
    </div>
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">🏗️ Fill Dirt</div>
      <div class="text-slate-400 text-sm">Sub-soil without organics. Used to raise grade, fill holes, and compact well under structures.</div>
    </div>
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">🔄 Garden Soil</div>
      <div class="text-slate-400 text-sm">Pre-amended blend of topsoil, compost and organic matter. Ideal for raised garden beds.</div>
    </div>
  </div>

  <h2>Coverage Table</h2>
  <div class="panel overflow-hidden not-prose my-6">
    <table class="w-full text-sm">
      <thead>
        <tr class="bg-brand-slate">
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Area (sq ft)</th>
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">2" Deep</th>
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">4" Deep</th>
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">6" Deep</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-brand-slatelit">
        <tr><td class="px-4 py-3">100 sq ft</td><td class="px-4 py-3 text-brand-amber">0.62 yd³</td><td class="px-4 py-3 text-brand-amber">1.23 yd³</td><td class="px-4 py-3 text-brand-amber">1.85 yd³</td></tr>
        <tr><td class="px-4 py-3">250 sq ft</td><td class="px-4 py-3 text-brand-amber">1.54 yd³</td><td class="px-4 py-3 text-brand-amber">3.09 yd³</td><td class="px-4 py-3 text-brand-amber">4.63 yd³</td></tr>
        <tr><td class="px-4 py-3">500 sq ft</td><td class="px-4 py-3 text-brand-amber">3.09 yd³</td><td class="px-4 py-3 text-brand-amber">6.17 yd³</td><td class="px-4 py-3 text-brand-amber">9.26 yd³</td></tr>
        <tr><td class="px-4 py-3">1,000 sq ft</td><td class="px-4 py-3 text-brand-amber">6.17 yd³</td><td class="px-4 py-3 text-brand-amber">12.35 yd³</td><td class="px-4 py-3 text-brand-amber">18.52 yd³</td></tr>
      </tbody>
    </table>
  </div>

  <h2>Tips for Ordering Dirt</h2>
  <ul>
    <li>Order <strong>10–15% more</strong> than calculated — dirt settles after it's spread and compacted.</li>
    <li>Fill dirt is usually sold by the <strong>cubic yard</strong> and delivered by truck (typically 10 or 14 yd³ loads).</li>
    <li>For lawn topdressing, a depth of <strong>1/2–1 inch</strong> is usually sufficient.</li>
    <li>Test your soil before adding topsoil — you may only need compost to improve existing soil.</li>
  </ul>

  <h2>Frequently Asked Questions</h2>
  <div class="not-prose space-y-2 my-6">
    <details class="panel faq-item">
      <summary>How much does a cubic yard of dirt weigh?</summary>
      <div class="faq-body">A cubic yard of topsoil weighs approximately 1,080–1,350 kg (2,200–3,000 lbs), depending on moisture content. Fill dirt is typically lighter at around 1,000–1,200 kg/yd³.</div>
    </details>
    <details class="panel faq-item">
      <summary>What's the difference between fill dirt and topsoil?</summary>
      <div class="faq-body">Fill dirt is subsoil without organic material — it compacts well and is used to raise grades. Topsoil is the nutrient-rich top layer used for growing plants.</div>
    </details>
    <details class="panel faq-item">
      <summary>How deep should topsoil be for a lawn?</summary>
      <div class="faq-body">6 inches (15 cm) of quality topsoil is ideal for establishing a new lawn. For overseeding and topdressing existing lawns, 1/4 to 1/2 inch is sufficient.</div>
    </details>
  </div>

</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
