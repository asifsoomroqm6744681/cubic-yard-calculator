<?php
/**
 * pages/terms-and-conditions.php – Terms and Conditions Page
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = t('page_terms_title', $strings);

$meta = [
  'title'       => t('page_terms_title', $strings) . ' | CubicYard',
  'description' => 'Terms and Conditions for using Cubic Yard Calculator.',
];

include __DIR__ . '/../inc/header.php';
?>

<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      <?php echo t('page_terms_title', $strings); ?>
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      Please read these terms carefully.
    </p>
  </div>
</section>

<section class="max-w-4xl mx-auto px-4 py-10 prose prose-invert prose-brand prose-sm sm:prose-base">
  <div class="panel p-6 sm:p-10">
    <h2>1. Acceptance of Terms</h2>
    <p>By accessing and using Cubic Yard Calculator, you accept and agree to be bound by the terms and provision of this agreement.</p>

    <h2>2. Use License</h2>
    <p>Permission is granted to use the calculators on Cubic Yard Calculator for personal or commercial use. This is the grant of a license, not a transfer of title, and under this license you may not:</p>
    <ul>
      <li>Modify or copy the materials for resale.</li>
      <li>Attempt to decompile or reverse engineer any software contained on the website.</li>
      <li>Remove any copyright or other proprietary notations from the materials.</li>
    </ul>

    <h2>3. Disclaimer</h2>
    <p>The materials on Cubic Yard Calculator are provided on an 'as is' basis. We make no warranties, expressed or implied, and hereby disclaim and negate all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
    <p><strong>Note:</strong> Calculations provided by our tools are estimates only. Always consult with a professional contractor before ordering materials.</p>

    <h2>4. Limitations</h2>
    <p>In no event shall Cubic Yard Calculator or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on the website.</p>

    <h2>5. Governing Law</h2>
    <p>Any claim relating to Cubic Yard Calculator's website shall be governed by the laws of the operating jurisdiction without regard to its conflict of law provisions.</p>
  </div>
</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
