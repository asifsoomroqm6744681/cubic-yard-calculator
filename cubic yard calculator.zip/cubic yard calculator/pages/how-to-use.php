<?php
/**
 * pages/how-to-use.php – How To Use Guide
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = 'How To Use';

$meta = [
  'title'       => 'How to Use the Cubic Yard Calculator – Step-by-Step Guide',
  'description' => 'Learn how to use our free cubic yard calculator to accurately estimate material quantities for concrete, dirt, gravel and more.',
];
$siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
         . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
$jsonld = '';

include __DIR__ . '/../inc/header.php';
?>

<!-- Hero -->
<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <div class="inline-flex items-center gap-2 bg-brand-slatelit/60 border border-brand-slatelit rounded-full px-4 py-1.5 text-xs text-brand-amber font-semibold uppercase tracking-widest mb-5">
      <span>📖</span> Guide
    </div>
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      How To Use the Calculator
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      Get accurate cubic yard results in 3 simple steps — no maths required.
    </p>
  </div>
</section>

<!-- Steps -->
<section class="max-w-4xl mx-auto px-4 py-10">
  <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
    <div class="panel p-6 text-center">
      <div class="w-12 h-12 rounded-full bg-brand-amber/20 border border-brand-amber flex items-center justify-center text-brand-amber font-black text-xl mx-auto mb-4">1</div>
      <h2 class="text-white font-bold text-base mb-2">Choose Your Shape</h2>
      <p class="text-slate-400 text-sm">Select <strong class="text-white">Rectangle / Square</strong> for slabs, beds, and floors — or <strong class="text-white">Cylinder / Round</strong> for columns, poles, and circular areas.</p>
    </div>
    <div class="panel p-6 text-center">
      <div class="w-12 h-12 rounded-full bg-brand-amber/20 border border-brand-amber flex items-center justify-center text-brand-amber font-black text-xl mx-auto mb-4">2</div>
      <h2 class="text-white font-bold text-base mb-2">Enter Your Dimensions</h2>
      <p class="text-slate-400 text-sm">Choose your unit (feet, inches or cm), then enter <strong class="text-white">Length, Width</strong> and <strong class="text-white">Depth</strong>. For cylinders, enter <strong class="text-white">Diameter</strong> and <strong class="text-white">Depth</strong>.</p>
    </div>
    <div class="panel p-6 text-center">
      <div class="w-12 h-12 rounded-full bg-brand-amber/20 border border-brand-amber flex items-center justify-center text-brand-amber font-black text-xl mx-auto mb-4">3</div>
      <h2 class="text-white font-bold text-base mb-2">Read Your Results</h2>
      <p class="text-slate-400 text-sm">See instant results in <strong class="text-white">cubic yards</strong>, cubic feet, and bag counts for 60 lb and 80 lb concrete bags.</p>
    </div>
  </div>

  <div class="prose-dark">
    <h2>Understanding the Results</h2>

    <div class="panel overflow-hidden not-prose my-6">
      <table class="w-full text-sm">
        <thead>
          <tr class="bg-brand-slate">
            <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Result</th>
            <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">What It Means</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-brand-slatelit">
          <tr><td class="px-4 py-3 font-semibold text-brand-amber">Cubic Yards</td><td class="px-4 py-3 text-slate-300">The standard unit for ordering ready-mix concrete, topsoil, gravel and mulch in the USA.</td></tr>
          <tr><td class="px-4 py-3 font-semibold text-sky-300">Cubic Feet</td><td class="px-4 py-3 text-slate-300">Useful for smaller projects or comparing with bag coverage.</td></tr>
          <tr><td class="px-4 py-3 font-semibold text-green-300">60 lb Bags</td><td class="px-4 py-3 text-slate-300">How many standard 60 lb bags of QUIKRETE® or similar you'll need (0.45 ft³ yield per bag).</td></tr>
          <tr><td class="px-4 py-3 font-semibold text-red-300">80 lb Bags</td><td class="px-4 py-3 text-slate-300">How many 80 lb bags you'll need (0.60 ft³ yield per bag). Fewer bags, more weight to carry.</td></tr>
        </tbody>
      </table>
    </div>

    <h2>The Formula Explained</h2>

    <h3>Rectangular / Square</h3>
    <div class="panel p-4 my-3 font-mono text-sm text-brand-amber not-prose">
      Cubic Yards = (Length × Width × Depth in feet) ÷ 27
    </div>
    <p>Since 1 cubic yard = 27 cubic feet, you divide the total cubic feet by 27. If your measurements are in inches, divide each by 12 first. The calculator does this automatically when you select your unit.</p>

    <h3>Cylinder / Round</h3>
    <div class="panel p-4 my-3 font-mono text-sm text-brand-amber not-prose">
      Cubic Yards = (π × radius² × Depth in feet) ÷ 27
    </div>
    <p>Radius = Diameter ÷ 2. Our calculator handles the unit conversion and pi (π ≈ 3.14159) automatically.</p>

    <h2>Unit Conversion Reference</h2>
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 not-prose my-6">
      <div class="panel p-4">
        <div class="text-brand-amber font-bold text-sm mb-2">Feet → Yards</div>
        <div class="text-slate-300 font-mono text-sm">÷ 3 for linear<br/>÷ 9 for sq ft<br/>÷ 27 for cu ft</div>
      </div>
      <div class="panel p-4">
        <div class="text-brand-amber font-bold text-sm mb-2">Inches → Feet</div>
        <div class="text-slate-300 font-mono text-sm">÷ 12<br/><br/>e.g. 4" = 0.333 ft</div>
      </div>
      <div class="panel p-4">
        <div class="text-brand-amber font-bold text-sm mb-2">cm → Feet</div>
        <div class="text-slate-300 font-mono text-sm">÷ 30.48<br/><br/>e.g. 120 cm = 3.94 ft</div>
      </div>
    </div>

    <h2>Calculation History</h2>
    <p>Every calculation you run is automatically saved in your browser's local storage. You can view recent calculations in the <strong>History</strong> table on the homepage, or clear them at any time. No account is needed — your data never leaves your device.</p>

    <h2>Frequently Asked Questions</h2>
    <div class="not-prose space-y-2 my-6">
      <details class="panel faq-item">
        <summary>Do I need to register or create an account?</summary>
        <div class="faq-body">No account is needed. The calculator is completely free to use and works entirely in your browser. Calculation history is saved locally on your device.</div>
      </details>
      <details class="panel faq-item">
        <summary>What if my measurements are mixed units?</summary>
        <div class="faq-body">Convert all measurements to the same unit first, then select that unit in the calculator. For example, if your area is 10 ft wide but depth is 4 inches, either convert depth to feet (4 ÷ 12 = 0.333 ft) and select "Feet", or convert width to inches (10 × 12 = 120 in) and select "Inches".</div>
      </details>
      <details class="panel faq-item">
        <summary>How accurate are the bag count results?</summary>
        <div class="faq-body">Bag counts are estimates based on manufacturer stated yields (0.45 ft³ for 60 lb, 0.60 ft³ for 80 lb). Actual yield varies slightly by brand and mixing conditions. Always add 10% to your order for waste.</div>
      </details>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
