<?php
/**
 * pages/gravel.php – Gravel Calculator Guide
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = 'Gravel Calculator';

$meta = [
  'title'       => 'Gravel Calculator – Cubic Yards for Driveways & Landscaping | CubicYard',
  'description' => 'Calculate cubic yards of gravel or crushed stone for your driveway, pathway, or landscaping project. Free gravel cubic yard calculator.',
];
$siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
         . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
$jsonld = '';

include __DIR__ . '/../inc/header.php';
?>

<!-- Hero -->
<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <div class="inline-flex items-center gap-2 bg-brand-slatelit/60 border border-brand-slatelit rounded-full px-4 py-1.5 text-xs text-brand-amber font-semibold uppercase tracking-widest mb-5">
      <span>🪨</span> Material Guide
    </div>
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      Gravel Calculator
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      Find how many cubic yards of gravel you need for any driveway, pathway or landscape project.
    </p>
  </div>
</section>

<!-- Content -->
<section class="max-w-4xl mx-auto px-4 py-10 prose-dark">

  <!-- Quick-calc embed -->
  <div class="panel p-6 mb-10">
    <h2 class="text-lg font-bold text-white mb-1 flex items-center gap-2">
      <span class="text-brand-amber">⚡</span> Quick Gravel Calculator
    </h2>
    <p class="text-sm text-slate-400 mb-5">Enter your area dimensions:</p>
    <form id="form-rect" novalidate>
      <fieldset class="border-0 p-0 m-0 space-y-4">
        <legend class="sr-only">Rectangular area inputs</legend>
        <div class="flex items-center justify-between mb-2">
          <span class="text-sm font-semibold text-slate-400 uppercase tracking-wider">Unit of Measurement</span>
          <select id="rect-unit" class="calc-input w-36 text-sm">
            <option value="ft">Feet</option>
            <option value="in">Inches</option>
            <option value="cm">Centimeters</option>
          </select>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label for="rect-length" class="block text-sm font-semibold text-slate-300 mb-1.5">Length</label>
            <input id="rect-length" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 50" required />
          </div>
          <div>
            <label for="rect-width" class="block text-sm font-semibold text-slate-300 mb-1.5">Width</label>
            <input id="rect-width" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 10" required />
          </div>
          <div>
            <label for="rect-depth" class="block text-sm font-semibold text-slate-300 mb-1.5">Depth</label>
            <input id="rect-depth" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 0.25" required />
          </div>
        </div>
      </fieldset>
      <div id="error-msg" class="hidden mt-3 rounded-lg bg-red-900/40 border border-red-700 text-red-300 px-4 py-3 text-sm" role="alert"></div>
      <div class="flex gap-3 mt-5">
        <button type="submit" class="btn-primary flex-1">Calculate Gravel</button>
        <button type="button" id="btn-clear-rect" class="btn-secondary">Clear</button>
      </div>
    </form>
    <div id="results-panel" class="hidden mt-6 pt-5 border-t border-brand-slatelit">
      <h3 class="text-base font-bold text-white mb-3 flex items-center gap-2">
        <span class="text-brand-amber">✓</span> Your Results
      </h3>
      <div class="grid grid-cols-2 gap-3">
        <div class="result-card pulse-amber">
          <div id="result-cubic-yards" class="result-value">—</div>
          <div class="result-label">Cubic Yards</div>
        </div>
        <div class="result-card">
          <div id="result-cubic-feet" class="result-value" style="color:#7dd3fc">—</div>
          <div class="result-label">Cubic Feet</div>
        </div>
        <div id="result-bags-60" class="hidden"></div>
        <div id="result-bags-80" class="hidden"></div>
      </div>
    </div>
  </div>

  <h2>Gravel Types &amp; Their Uses</h2>
  <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 not-prose my-6">
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">🔘 Pea Gravel</div>
      <div class="text-slate-400 text-sm">Small, smooth stones (3/8"). Great for walkways, playgrounds, and drainage.</div>
    </div>
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">🔘 Crushed Stone (3/4")</div>
      <div class="text-slate-400 text-sm">Best for driveways and base layers. Compacts well and provides stability.</div>
    </div>
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">🔘 River Rock</div>
      <div class="text-slate-400 text-sm">Large, smooth. Decorative landscaping, drainage swales, and dry creek beds.</div>
    </div>
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">🔘 Decomposed Granite</div>
      <div class="text-slate-400 text-sm">Fine, compacts to a stable surface. Ideal for paths, patios, and xeriscaping.</div>
    </div>
  </div>

  <h2>Gravel Depth Guide</h2>
  <div class="panel overflow-hidden not-prose my-6">
    <table class="w-full text-sm">
      <thead>
        <tr class="bg-brand-slate">
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Application</th>
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Recommended Depth</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-brand-slatelit">
        <tr><td class="px-4 py-3">Walkway / Pathway</td><td class="px-4 py-3 text-brand-amber">2–3 inches</td></tr>
        <tr><td class="px-4 py-3">Residential Driveway</td><td class="px-4 py-3 text-brand-amber">4–6 inches</td></tr>
        <tr><td class="px-4 py-3">Decorative Landscaping</td><td class="px-4 py-3 text-brand-amber">2–3 inches</td></tr>
        <tr><td class="px-4 py-3">Drainage / French Drain</td><td class="px-4 py-3 text-brand-amber">12+ inches</td></tr>
        <tr><td class="px-4 py-3">Foundation Base</td><td class="px-4 py-3 text-brand-amber">4–6 inches</td></tr>
      </tbody>
    </table>
  </div>

  <h2>Tips for Ordering Gravel</h2>
  <ul>
    <li>Order <strong>10% extra</strong> to account for compaction and settling — gravel reduces in volume when compacted.</li>
    <li>For driveways, use <strong>two layers</strong>: a 4" base of crushed stone, then 2" of finish gravel on top.</li>
    <li>Install <strong>landscape fabric</strong> underneath to suppress weeds while maintaining drainage.</li>
    <li>Always ask about <strong>compaction factor</strong> — crushed stone can compact 15–30% from its loose volume.</li>
  </ul>

  <h2>Frequently Asked Questions</h2>
  <div class="not-prose space-y-2 my-6">
    <details class="panel faq-item">
      <summary>How much does a cubic yard of gravel weigh?</summary>
      <div class="faq-body">One cubic yard of gravel typically weighs 2,700–3,400 lbs (1,200–1,550 kg) depending on the stone type and moisture. Pea gravel is around 2,700 lbs/yd³.</div>
    </details>
    <details class="panel faq-item">
      <summary>How many square feet does a yard of gravel cover?</summary>
      <div class="faq-body">At 2" deep: ~162 sq ft. At 3" deep: ~108 sq ft. At 4" deep: ~81 sq ft. At 6" deep: ~54 sq ft.</div>
    </details>
    <details class="panel faq-item">
      <summary>What gravel is best for a driveway?</summary>
      <div class="faq-body">For driveways, #57 or #411 crushed stone (3/4"–1") makes the best base. For the top layer, use pea gravel or 3/8" crushed stone for a cleaner finish.</div>
    </details>
  </div>

</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
