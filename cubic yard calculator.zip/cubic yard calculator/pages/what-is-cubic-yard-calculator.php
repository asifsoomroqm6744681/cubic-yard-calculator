<?php
/**
 * pages/what-is-cubic-yard-calculator.php – Informational Guide
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = 'What Is a Cubic Yard?';

$meta = [
  'title'       => 'What Is a Cubic Yard Calculator? – Complete Guide',
  'description' => 'Learn what a cubic yard is, how a cubic yard calculator works, and why it is the standard unit for concrete, topsoil and gravel projects in the US.',
];
$siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
         . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
$jsonld = '';

include __DIR__ . '/../inc/header.php';
?>

<!-- Hero -->
<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <div class="inline-flex items-center gap-2 bg-brand-slatelit/60 border border-brand-slatelit rounded-full px-4 py-1.5 text-xs text-brand-amber font-semibold uppercase tracking-widest mb-5">
      <span>📐</span> Learning Guide
    </div>
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      What Is a Cubic Yard Calculator?
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      Everything you need to know about cubic yards and why they matter for construction and landscaping.
    </p>
  </div>
</section>

<!-- Content -->
<section class="max-w-4xl mx-auto px-4 py-10 prose-dark">

  <h2>What Is a Cubic Yard?</h2>
  <p>A <strong>cubic yard</strong> is a unit of volume measurement equal to a cube that is <strong>1 yard (3 feet) on each side</strong>. That equals:</p>

  <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 not-prose my-6">
    <div class="panel p-5 text-center">
      <div class="text-3xl font-black text-brand-amber mb-1">27</div>
      <div class="text-white font-semibold text-sm">Cubic Feet</div>
      <div class="text-slate-500 text-xs mt-1">3 × 3 × 3 ft</div>
    </div>
    <div class="panel p-5 text-center">
      <div class="text-3xl font-black text-brand-amber mb-1">46,656</div>
      <div class="text-white font-semibold text-sm">Cubic Inches</div>
      <div class="text-slate-500 text-xs mt-1">36 × 36 × 36 in</div>
    </div>
    <div class="panel p-5 text-center">
      <div class="text-3xl font-black text-brand-amber mb-1">0.765</div>
      <div class="text-white font-semibold text-sm">Cubic Metres</div>
      <div class="text-slate-500 text-xs mt-1">SI equivalent</div>
    </div>
  </div>

  <p>In the United States, the cubic yard is the <strong>standard unit for ordering bulk materials</strong> like concrete, topsoil, gravel, mulch, and sand. When you call a ready-mix plant or landscape supplier, quantities are quoted per cubic yard.</p>

  <h2>What Is a Cubic Yard Calculator?</h2>
  <p>A <strong>cubic yard calculator</strong> is a tool that computes the volume of a space in cubic yards given its dimensions (length, width, depth). Rather than doing the maths by hand — converting inches to feet, multiplying L × W × D, then dividing by 27 — the calculator does everything instantly.</p>
  <p>Our free tool supports both <strong>rectangular/square</strong> areas and <strong>cylindrical/round</strong> areas, and accepts measurements in feet, inches, or centimetres.</p>

  <h2>Why Cubic Yards?</h2>
  <p>Most construction and landscaping materials are sold and delivered by the cubic yard because:</p>
  <ul>
    <li><strong>It's a practical size</strong> — 1 cubic yard of concrete fills a typical 10×10 ft slab to a 3.24-inch depth.</li>
    <li><strong>Industry standard</strong> — ready-mix trucks, bulk material suppliers, and project estimating all use the cubic yard.</li>
    <li><strong>Cost basis</strong> — pricing is quoted per cubic yard, so you need accurate yardage to get accurate quotes.</li>
  </ul>

  <h2>When Do You Need a Cubic Yard Calculator?</h2>
  <ul>
    <li>Pouring a <strong>concrete slab</strong> (driveway, patio, basement floor)</li>
    <li>Ordering <strong>topsoil</strong> or <strong>fill dirt</strong> for grading a yard</li>
    <li>Estimating <strong>gravel</strong> for a driveway or drainage project</li>
    <li>Buying <strong>mulch</strong> for planting beds</li>
    <li>Calculating <strong>sand</strong> for a sandbox or leveling project</li>
  </ul>

  <h2>How the Calculation Works</h2>
  <h3>Rectangular Areas</h3>
  <div class="panel p-4 my-3 font-mono text-sm text-brand-amber not-prose">
    Cubic Yards = (L ft × W ft × D ft) ÷ 27
  </div>

  <h3>Cylindrical Areas</h3>
  <div class="panel p-4 my-3 font-mono text-sm text-brand-amber not-prose">
    Cubic Yards = (π × r² ft × D ft) ÷ 27
  </div>
  <p>Where <em>r</em> is the radius (diameter ÷ 2) and all measurements are in feet.</p>

  <h2>Quick Reference Card</h2>
  <div class="panel overflow-hidden not-prose my-6">
    <table class="w-full text-sm">
      <thead>
        <tr class="bg-brand-slate">
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Conversion</th>
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Value</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-brand-slatelit">
        <tr><td class="px-4 py-3">1 cubic yard</td><td class="px-4 py-3 text-brand-amber">= 27 cubic feet</td></tr>
        <tr><td class="px-4 py-3">1 cubic yard</td><td class="px-4 py-3 text-brand-amber">= 46,656 cubic inches</td></tr>
        <tr><td class="px-4 py-3">1 cubic yard</td><td class="px-4 py-3 text-brand-amber">≈ 0.7646 cubic metres</td></tr>
        <tr><td class="px-4 py-3">1 cubic foot</td><td class="px-4 py-3 text-brand-amber">= 1,728 cubic inches</td></tr>
        <tr><td class="px-4 py-3">1 foot</td><td class="px-4 py-3 text-brand-amber">= 12 inches = 30.48 cm</td></tr>
      </tbody>
    </table>
  </div>

  <div class="panel p-6 my-8 text-center not-prose">
    <div class="text-brand-amber text-2xl mb-3">⚡</div>
    <h3 class="text-white font-bold text-lg mb-2">Ready to Calculate?</h3>
    <p class="text-slate-400 text-sm mb-5">Use our free calculator to get instant results for your project.</p>
    <a href="/" class="btn-primary inline-block">Go to Calculator →</a>
  </div>

  <h2>Frequently Asked Questions</h2>
  <div class="not-prose space-y-2 my-6">
    <details class="panel faq-item">
      <summary>Is a cubic yard the same as a yard?</summary>
      <div class="faq-body">No. A yard is a linear measurement of length (3 feet). A cubic yard is a volume measurement — it's a cube where each edge is 1 yard (3 feet) long, giving a total volume of 27 cubic feet.</div>
    </details>
    <details class="panel faq-item">
      <summary>How do I measure depth accurately?</summary>
      <div class="faq-body">For consistent depth projecs (like concrete slabs), measure at multiple points and use the average. For irregular terrain, measure at the deepest and shallowest points and average them.</div>
    </details>
    <details class="panel faq-item">
      <summary>Are cubic yards used outside the US?</summary>
      <div class="faq-body">Primarily in the USA, Canada, and UK for some applications. Most other countries use cubic metres (m³). 1 cubic yard ≈ 0.7646 m³.</div>
    </details>
    <details class="panel faq-item">
      <summary>How much does 1 cubic yard of material weigh?</summary>
      <div class="faq-body">It varies by material: Concrete ≈ 4,050 lbs, Topsoil ≈ 2,600 lbs, Gravel ≈ 3,000 lbs, Mulch ≈ 800 lbs. Keep weight in mind when hiring delivery trucks.</div>
    </details>
  </div>

</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
