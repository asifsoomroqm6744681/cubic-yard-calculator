<?php
/**
 * pages/privacy-policy.php – Privacy Policy Page
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = t('page_privacy_title', $strings);

$meta = [
  'title'       => t('page_privacy_title', $strings) . ' | CubicYard',
  'description' => 'Privacy Policy for Cubic Yard Calculator. Learn how we handle your data.',
];

include __DIR__ . '/../inc/header.php';
?>

<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      <?php echo t('page_privacy_title', $strings); ?>
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      Last updated: February 2026
    </p>
  </div>
</section>

<section class="max-w-4xl mx-auto px-4 py-10 prose prose-invert prose-brand prose-sm sm:prose-base">
  <div class="panel p-6 sm:p-10">
    <h2>1. Information We Collect</h2>
    <p>Cubic Yard Calculator is designed to be a "tools-first" utility. We do not require you to create an account or provide personal identification information to use our calculators.</p>
    <p>However, like most websites, we may collect non-identifying information such as:</p>
    <ul>
      <li>Browser type and version</li>
      <li>Operating system</li>
      <li>IP address (for security and anti-abuse purposes)</li>
      <li>Usage patterns (time spent on site, pages visited)</li>
    </ul>

    <h2>2. Use of LocalStorage</h2>
    <p>Our calculator uses <strong>LocalStorage</strong> on your device to save your calculation history. This data remains on your computer and is not uploaded to our servers. You can clear this history at any time using the "Clear History" button on the main page.</p>

    <h2>3. Cookies and Tracking</h2>
    <p>We use essential cookies to manage language preferences and basic site functionality. We may also use third-party services like Google Analytics to help us understand site performance.</p>

    <h2>4. Third-Party Links</h2>
    <p>Our site may contain links to other websites. We are not responsible for the privacy practices or content of those external sites.</p>

    <h2>5. Changes to This Policy</h2>
    <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>

    <h2>6. Contact Us</h2>
    <p>If you have any questions about this Privacy Policy, please contact us through our contact page.</p>
  </div>
</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
