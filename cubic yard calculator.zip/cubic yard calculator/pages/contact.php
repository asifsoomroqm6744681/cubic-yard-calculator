<?php
/**
 * pages/contact.php – Contact Page
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = t('page_contact_title', $strings);

$meta = [
  'title'       => t('page_contact_title', $strings) . ' | CubicYard',
  'description' => 'Get in touch with the team at Cubic Yard Calculator.',
];

include __DIR__ . '/../inc/header.php';
?>

<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      <?php echo t('page_contact_title', $strings); ?>
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      We'd love to hear from you.
    </p>
  </div>
</section>

<section class="max-w-4xl mx-auto px-4 py-10 prose prose-invert prose-brand prose-sm sm:prose-base">
  <div class="grid grid-cols-1 md:grid-cols-2 gap-8 not-prose">
    
    <!-- Contact Form -->
    <div class="panel p-6 sm:p-8">
      <h2 class="text-xl font-bold text-white mb-6">Send us a message</h2>
      <form action="#" method="POST" class="space-y-4">
        <div>
          <label for="name" class="block text-sm font-medium text-slate-400 mb-1">Name</label>
          <input type="text" id="name" name="name" class="calc-input" placeholder="Your Name" required>
        </div>
        <div>
          <label for="email" class="block text-sm font-medium text-slate-400 mb-1">Email</label>
          <input type="email" id="email" name="email" class="calc-input" placeholder="Your Email" required>
        </div>
        <div>
          <label for="message" class="block text-sm font-medium text-slate-400 mb-1">Message</label>
          <textarea id="message" name="message" rows="4" class="calc-input" placeholder="How can we help?" required></textarea>
        </div>
        <button type="submit" class="btn-primary w-full py-3">Send Message</button>
      </form>
      <p class="text-xs text-slate-600 mt-4 text-center">Note: This is a demo form. For a real site, connect this to a backend mailer.</p>
    </div>

    <!-- Contact Info -->
    <div class="flex flex-col gap-6">
      <div class="panel p-6 sm:p-8">
        <h3 class="text-lg font-bold text-white mb-3">Email Support</h3>
        <p class="text-slate-400">For general inquiries, material suggestions, or technical support, drop us a line at:</p>
        <a href="mailto:support@cubicyardcalc.com" class="text-brand-amber font-semibold mt-2 inline-block">support@cubicyardcalc.com</a>
      </div>

      <div class="panel p-6 sm:p-8">
        <h3 class="text-lg font-bold text-white mb-3">Material Partners</h3>
        <p class="text-slate-400">Are you a material supplier? We're always looking for accurate density data and partnership opportunities.</p>
        <a href="mailto:partners@cubicyardcalc.com" class="text-brand-amber font-semibold mt-2 inline-block">partners@cubicyardcalc.com</a>
      </div>
    </div>

  </div>
</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
