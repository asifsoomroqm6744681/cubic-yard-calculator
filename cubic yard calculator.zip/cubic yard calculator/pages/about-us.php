<?php
/**
 * pages/about-us.php – About Us Page
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = t('page_about_title', $strings);

$meta = [
  'title'       => t('page_about_title', $strings) . ' | CubicYard',
  'description' => 'Learn more about Cubic Yard Calculator, our mission, and our tools.',
];

include __DIR__ . '/../inc/header.php';
?>

<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      <?php echo t('page_about_title', $strings); ?>
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      Making construction math simple for everyone.
    </p>
  </div>
</section>

<section class="max-w-4xl mx-auto px-4 py-10 prose prose-invert prose-brand prose-sm sm:prose-base">
  <div class="panel p-6 sm:p-10">
    <h2>Our Mission</h2>
    <p>At <strong>CubicYard</strong>, our mission is to provide construction professionals, contractors, and DIY enthusiasts with the fastest and most accurate calculation tools for their projects.</p>
    <p>We believe that estimating materials shouldn't be a headache. Whether you're pouring a new driveway, filling a garden bed, or laying a gravel path, our goal is to help you get the numbers right the first time, saving you time and money.</p>

    <h2>Why Use Our Calculator?</h2>
    <ul>
      <li><strong>Accuracy:</strong> Our formulas are industry-standard and tested.</li>
      <li><strong>Simplicity:</strong> We focus on a clean, fast UI that works on any device.</li>
      <li><strong>Global Support:</strong> With support for over 14 languages, we serve users worldwide.</li>
      <li><strong>Privacy First:</strong> Your calculations stay on your device. We don't track your personal data.</li>
    </ul>

    <h2>The Team</h2>
    <p>CubicYard was founded by a team of software engineers and construction enthusiasts who saw a need for better online tools. We are constantly improving our algorithms and adding new materials to our library.</p>

    <div class="mt-8 pt-8 border-t border-brand-slatelit text-center">
      <p class="text-slate-400 italic">"Precision in every yard."</p>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
