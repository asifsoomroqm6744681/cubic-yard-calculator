<?php
/**
 * pages/concrete.php – Concrete Calculator Guide
 */
require_once __DIR__ . '/../functions.php';

$lang    = getCurrentLang();
$strings = loadLang($lang);
$breadcrumb = 'Concrete Calculator';

$meta = [
  'title'       => 'Concrete Calculator – Cubic Yards for Concrete Slabs | CubicYard',
  'description' => 'Calculate exactly how many cubic yards of concrete you need for any slab, footing, column, or pour. Free online concrete cubic yard calculator.',
];
$siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
         . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
$jsonld = '';

include __DIR__ . '/../inc/header.php';
?>

<!-- Hero -->
<section class="hero-gradient py-10 px-4 text-center">
  <div class="max-w-3xl mx-auto">
    <div class="inline-flex items-center gap-2 bg-brand-slatelit/60 border border-brand-slatelit rounded-full px-4 py-1.5 text-xs text-brand-amber font-semibold uppercase tracking-widest mb-5">
      <span>🏗️</span> Material Guide
    </div>
    <h1 class="text-3xl md:text-5xl font-extrabold text-white leading-tight mb-4">
      Concrete Calculator
    </h1>
    <p class="text-base md:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
      Find out exactly how many cubic yards of concrete you need — no guesswork.
    </p>
  </div>
</section>

<!-- Content -->
<section class="max-w-4xl mx-auto px-4 py-10 prose-dark">

  <!-- Quick-calc embed -->
  <div class="panel p-6 mb-10">
    <h2 class="text-lg font-bold text-white mb-1 flex items-center gap-2">
      <span class="text-brand-amber">⚡</span> Quick Concrete Calculator
    </h2>
    <p class="text-sm text-slate-400 mb-5">Enter your slab dimensions below:</p>

    <form id="form-rect" novalidate>
      <fieldset class="border-0 p-0 m-0 space-y-4">
        <legend class="sr-only">Rectangular area inputs</legend>
        <div class="flex items-center justify-between mb-2">
          <span class="text-sm font-semibold text-slate-400 uppercase tracking-wider">Unit of Measurement</span>
          <select id="rect-unit" class="calc-input w-36 text-sm">
            <option value="ft">Feet</option>
            <option value="in">Inches</option>
            <option value="cm">Centimeters</option>
          </select>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label for="rect-length" class="block text-sm font-semibold text-slate-300 mb-1.5">Length</label>
            <input id="rect-length" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 12" required />
          </div>
          <div>
            <label for="rect-width" class="block text-sm font-semibold text-slate-300 mb-1.5">Width</label>
            <input id="rect-width" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 8" required />
          </div>
          <div>
            <label for="rect-depth" class="block text-sm font-semibold text-slate-300 mb-1.5">Depth / Thickness</label>
            <input id="rect-depth" type="number" class="calc-input" min="0.001" step="any" placeholder="e.g. 4" required />
          </div>
        </div>
      </fieldset>
      <div id="error-msg" class="hidden mt-3 rounded-lg bg-red-900/40 border border-red-700 text-red-300 px-4 py-3 text-sm" role="alert"></div>
      <div class="flex gap-3 mt-5">
        <button type="submit" class="btn-primary flex-1">Calculate Concrete</button>
        <button type="button" id="btn-clear-rect" class="btn-secondary">Clear</button>
      </div>
    </form>

    <!-- Results -->
    <div id="results-panel" class="hidden mt-6 pt-5 border-t border-brand-slatelit">
      <h3 class="text-base font-bold text-white mb-3 flex items-center gap-2">
        <span class="text-brand-amber">✓</span> Your Results
      </h3>
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div class="result-card pulse-amber">
          <div id="result-cubic-yards" class="result-value">—</div>
          <div class="result-label">Cubic Yards</div>
        </div>
        <div class="result-card">
          <div id="result-cubic-feet" class="result-value" style="color:#7dd3fc">—</div>
          <div class="result-label">Cubic Feet</div>
        </div>
        <div class="result-card">
          <div id="result-bags-60" class="result-value" style="color:#86efac">—</div>
          <div class="result-label">60 lb Bags</div>
        </div>
        <div class="result-card">
          <div id="result-bags-80" class="result-value" style="color:#fca5a5">—</div>
          <div class="result-label">80 lb Bags</div>
        </div>
      </div>
      <p class="text-xs text-slate-500 mt-3">Bag counts are estimates — add 10% for waste.</p>
    </div>
  </div>

  <h2>What Is a Concrete Cubic Yard?</h2>
  <p>A cubic yard is the standard unit for measuring concrete volume in the United States. One cubic yard equals 27 cubic feet or roughly 0.765 cubic metres. Ready-mix concrete is ordered by the cubic yard, and pre-mixed bags are labelled to show how many bags fill one cubic yard.</p>

  <h2>How to Calculate Cubic Yards for Concrete</h2>
  <p>Use this simple formula for rectangular slabs:</p>
  <div class="panel p-4 mb-6 font-mono text-sm text-brand-amber">
    Cubic Yards = (Length × Width × Depth) ÷ 27
  </div>
  <p>All dimensions must be in <strong>feet</strong> before dividing by 27. The calculator above handles unit conversion automatically.</p>

  <h2>Concrete Mix Ratios</h2>
  <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 not-prose my-6">
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">1:2:3 Mix</div>
      <div class="text-slate-400 text-sm">Standard structural mix. Great for footings, slabs, and columns.</div>
    </div>
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">1:1.5:3 Mix</div>
      <div class="text-slate-400 text-sm">Stronger mix for heavy load applications and reinforced structures.</div>
    </div>
    <div class="panel p-4">
      <div class="text-brand-amber font-bold mb-1">1:3:6 Mix</div>
      <div class="text-slate-400 text-sm">Lean mix for non-structural fills, blinding, and levelling.</div>
    </div>
  </div>

  <h2>Bag Coverage Reference</h2>
  <div class="panel overflow-hidden not-prose my-6">
    <table class="w-full text-sm">
      <thead>
        <tr class="bg-brand-slate">
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Bag Size</th>
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Yield (ft³)</th>
          <th class="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wider">Bags per Cubic Yard</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-brand-slatelit">
        <tr><td class="px-4 py-3">40 lb</td><td class="px-4 py-3 text-brand-amber">0.30 ft³</td><td class="px-4 py-3">90 bags</td></tr>
        <tr><td class="px-4 py-3">60 lb</td><td class="px-4 py-3 text-brand-amber">0.45 ft³</td><td class="px-4 py-3">60 bags</td></tr>
        <tr><td class="px-4 py-3">80 lb</td><td class="px-4 py-3 text-brand-amber">0.60 ft³</td><td class="px-4 py-3">45 bags</td></tr>
      </tbody>
    </table>
  </div>

  <h2>Pro Tips</h2>
  <ul>
    <li>Always add <strong>5–10% extra</strong> to your order to account for spillage and uneven sub-base.</li>
    <li>For pours over <strong>1 cubic yard</strong>, consider ordering ready-mix concrete — it's cheaper per yard than bags.</li>
    <li>Cure concrete for at least <strong>7 days</strong> by keeping it moist before applying any load.</li>
    <li>In cold weather (below 40°F / 4°C), use a concrete blanket or heated enclosure to prevent freezing.</li>
  </ul>

  <h2>Frequently Asked Questions</h2>

  <div class="not-prose space-y-2 my-6">
    <details class="panel faq-item">
      <summary>How many bags of concrete make a cubic yard?</summary>
      <div class="faq-body">It takes approximately 45 bags of 80 lb concrete, 60 bags of 60 lb, or 90 bags of 40 lb to fill one cubic yard (27 cubic feet).</div>
    </details>
    <details class="panel faq-item">
      <summary>How deep should a concrete slab be?</summary>
      <div class="faq-body">A standard residential slab is typically 4 inches (10 cm) thick. Driveways should be 4–6 inches, and structural slabs for garages or heavy loads need 6+ inches.</div>
    </details>
    <details class="panel faq-item">
      <summary>Can I mix concrete myself for a large pour?</summary>
      <div class="faq-body">For pours under 0.5 cubic yards, DIY mixing is practical. Above that, renting a mixer or ordering ready-mix concrete saves significant time and effort.</div>
    </details>
  </div>

</section>

<?php include __DIR__ . '/../inc/nav.php'; ?>
<?php include __DIR__ . '/../inc/footer.php'; ?>
